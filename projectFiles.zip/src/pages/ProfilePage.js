import React from "react";
import UserProfile from "../components/Profile/UserProfile";

const ProfilePage = () => {
  return (
    <div>
      <UserProfile />
    </div>
  );
};

export default ProfilePage;
